const DEFAULT_TIMEOUT_MS = 12000;

export const API_BASE_URL = (
  process.env.EXPO_PUBLIC_API_BASE_URL ||
  (process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}/api` : "")
).replace(/\/$/, "");

export interface UserDocument {
  deviceId: string;
  installId?: string | null;
  deviceFingerprint?: string | null;
  firebaseUid?: string | null;
  authMode: "firebase-anonymous" | "device-only";
  authVerified: boolean;
  coinsBalance: number;
  pkrBalance: number;
  lastCheckInTimestamp: string | null;
  dailySpinsUsed: number;
  dailyScratchUsed: number;
  lastSpinResetDate: string | null;
  lastScratchResetDate: string | null;
  isBanned: boolean;
  banReason?: string | null;
  suspiciousScore?: number;
  fraudFlags?: string[];
  createdAt: string;
  updatedAt: string;
  lastActiveAt?: string;
  duplicateRestored?: boolean;
  authWarning?: string | null;
}

export interface RewardResult {
  success: boolean;
  message: string;
  coinsAwarded: number;
  rewardSegment?: number;
  spinsLeft?: number;
  scratchLeft?: number;
  balanceAfterCoins: number;
  balanceAfterPKR: number;
}

export interface WithdrawalDocument {
  withdrawalId: string;
  deviceId: string;
  paymentMethod: "Easypaisa" | "JazzCash";
  accountNumber: string;
  accountTitle: string;
  amountPKR: number;
  coinsDeducted: number;
  status: "pending" | "approved" | "rejected" | "paid";
  adminNote: string | null;
  rejectionReason: string | null;
  createdAt: string;
  updatedAt: string;
  processedAt: string | null;
  paidAt: string | null;
}

export interface TransactionDocument {
  transactionId: string;
  deviceId: string;
  type: "checkin" | "spin" | "scratch" | "offerwall" | "withdrawal_hold" | "withdrawal_refund" | "admin_adjustment";
  coinsChange: number;
  pkrChange: number;
  balanceAfterCoins?: number;
  balanceAfterPKR?: number;
  source: string;
  status: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
}

export interface SupportTicket {
  ticketId: string;
  deviceId: string;
  issueType: string;
  message: string;
  status: "open" | "replied" | "closed";
  createdAt: string;
  updatedAt: string;
}

interface InitUserPayload {
  deviceId: string;
  installId: string;
  deviceFingerprint: string;
  firebaseUid: string | null;
  firebaseToken: string | null;
  authMode: "firebase-anonymous" | "device-only";
  authVerified: boolean;
  deviceInfo: Record<string, unknown>;
}

async function apiFetch<T>(path: string, init: RequestInit = {}, timeoutMs = DEFAULT_TIMEOUT_MS): Promise<T> {
  if (!API_BASE_URL) {
    throw new Error("API URL is missing. Set EXPO_PUBLIC_API_BASE_URL in mobile secrets.");
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      headers: {
        "content-type": "application/json",
        ...(init.headers ?? {}),
      },
      signal: controller.signal,
    });
    const data = (await response.json().catch(() => ({}))) as { error?: string; message?: string } & T;
    if (!response.ok) {
      throw new Error(data.error || data.message || `Request failed (${response.status})`);
    }
    return data as T;
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Connection timed out. Check backend URL and network.");
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function initUser(payload: InitUserPayload): Promise<UserDocument> {
  return apiFetch<UserDocument>("/users/init", { method: "POST", body: JSON.stringify(payload) });
}

export async function getUser(deviceId: string): Promise<UserDocument> {
  return apiFetch<UserDocument>(`/users/${encodeURIComponent(deviceId)}`);
}

export async function checkIn(deviceId: string): Promise<RewardResult> {
  return apiFetch<RewardResult>(`/users/${encodeURIComponent(deviceId)}/checkin`, { method: "POST", body: JSON.stringify({}) });
}

export async function spin(deviceId: string): Promise<RewardResult> {
  return apiFetch<RewardResult>(`/users/${encodeURIComponent(deviceId)}/spin`, { method: "POST", body: JSON.stringify({}) });
}

export async function scratch(deviceId: string): Promise<RewardResult> {
  return apiFetch<RewardResult>(`/users/${encodeURIComponent(deviceId)}/scratch`, { method: "POST", body: JSON.stringify({}) });
}

export async function getTransactions(deviceId: string): Promise<TransactionDocument[]> {
  return apiFetch<TransactionDocument[]>(`/users/${encodeURIComponent(deviceId)}/transactions`);
}

export async function getWithdrawals(deviceId: string): Promise<WithdrawalDocument[]> {
  return apiFetch<WithdrawalDocument[]>(`/users/${encodeURIComponent(deviceId)}/withdrawals`);
}

export async function submitWithdrawal(deviceId: string, payload: {
  paymentMethod: "Easypaisa" | "JazzCash";
  accountNumber: string;
  accountTitle: string;
  amountPKR: number;
}): Promise<{ success: boolean; message: string; withdrawalId: string }> {
  return apiFetch(`/users/${encodeURIComponent(deviceId)}/withdrawals`, { method: "POST", body: JSON.stringify(payload) });
}

export async function getSupportTickets(deviceId: string): Promise<SupportTicket[]> {
  return apiFetch<SupportTicket[]>(`/users/${encodeURIComponent(deviceId)}/support`);
}

export async function submitSupportTicket(deviceId: string, payload: { issueType: string; message: string }): Promise<SupportTicket & { success: boolean }> {
  return apiFetch(`/users/${encodeURIComponent(deviceId)}/support`, { method: "POST", body: JSON.stringify(payload) });
}
