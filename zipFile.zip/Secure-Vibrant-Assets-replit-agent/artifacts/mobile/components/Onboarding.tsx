import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

const steps = [
  { icon: "star" as const, title: "Earn coins", body: "Complete daily check-in, spin wheel, scratch cards and offerwall tasks to collect coins." },
  { icon: "repeat" as const, title: "Convert to PKR", body: "Your conversion rate is fixed in the app: 1,000 coins = PKR 20." },
  { icon: "credit-card" as const, title: "Withdraw safely", body: "When your PKR balance reaches PKR 500, submit Easypaisa or JazzCash withdrawal details for review." },
  { icon: "shield" as const, title: "Fair play", body: "No VPN/proxy, bots, fake activity or multiple accounts. Suspicious activity can block rewards and withdrawals." },
];

export function Onboarding({ onDone }: { onDone: () => void }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}> 
      <LinearGradient colors={["#1A0A3A", "#0D0D1A"]} style={StyleSheet.absoluteFillObject} />
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 28, paddingBottom: insets.bottom + 28, paddingHorizontal: 20 }} showsVerticalScrollIndicator={false}>
        <View style={[styles.hero, { borderColor: colors.gold + "44" }]}> 
          <Feather name="gift" size={34} color={colors.gold} />
          <Text style={[styles.title, { color: colors.foreground }]}>Welcome to Engage to Earn</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Earn coins from valid activity and request PKR withdrawals after review.</Text>
        </View>

        <View style={styles.list}>
          {steps.map((step) => (
            <View key={step.title} style={[styles.step, { backgroundColor: colors.card, borderColor: colors.border }]}> 
              <View style={[styles.iconBox, { backgroundColor: colors.gold + "18" }]}> 
                <Feather name={step.icon} size={20} color={colors.gold} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.stepTitle, { color: colors.foreground }]}>{step.title}</Text>
                <Text style={[styles.stepBody, { color: colors.mutedForeground }]}>{step.body}</Text>
              </View>
            </View>
          ))}
        </View>

        <Pressable onPress={onDone} style={({ pressed }) => [{ opacity: pressed ? 0.88 : 1, transform: [{ scale: pressed ? 0.99 : 1 }] }]}> 
          <LinearGradient colors={[colors.goldLight, colors.gold, colors.orange]} style={styles.button}>
            <Text style={styles.buttonText}>I Understand · Start Earning</Text>
            <Feather name="arrow-right" size={18} color="#120900" />
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  hero: { borderWidth: 1, borderRadius: 28, padding: 22, alignItems: "center", backgroundColor: "rgba(255,255,255,0.05)", marginBottom: 18 },
  title: { fontFamily: "Inter_700Bold", fontSize: 28, textAlign: "center", marginTop: 12 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", marginTop: 8, lineHeight: 21 },
  list: { gap: 12, marginBottom: 20 },
  step: { flexDirection: "row", gap: 14, borderWidth: 1, borderRadius: 18, padding: 16 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  stepTitle: { fontFamily: "Inter_700Bold", fontSize: 15, marginBottom: 3 },
  stepBody: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 19 },
  button: { borderRadius: 18, padding: 17, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 10 },
  buttonText: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#120900" },
});
