import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

const sections = [
  { icon: "gift" as const, title: "Earn coins", body: "Use daily check-in, spin wheel, scratch cards and offerwall tasks to earn coins from valid activity." },
  { icon: "repeat" as const, title: "Coin conversion", body: "The app uses one clear rate everywhere: 1,000 coins = PKR 20." },
  { icon: "credit-card" as const, title: "Withdrawals", body: "When your balance reaches PKR 500, submit Easypaisa or JazzCash details. Payouts are reviewed before approval and payment." },
  { icon: "shield" as const, title: "Fair usage", body: "Do not use VPN, proxy, bots, emulators or fake activity. Use one account per device/user. Fraud can cause bans and rejected withdrawals." },
];
export default function HowItWorksScreen() {
  const colors = useColors(); const insets = useSafeAreaInsets(); const topPad = Platform.OS === "web" ? 28 : insets.top + 8;
  return <View style={[styles.root, { backgroundColor: colors.background, paddingTop: topPad }]}><View style={styles.header}><Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="arrow-left" size={20} color={colors.foreground} /></Pressable><View style={{ flex: 1 }}><Text style={[styles.title, { color: colors.foreground }]}>How It Works</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Simple earning and payout guide</Text></View></View><ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 34 }} showsVerticalScrollIndicator={false}>{sections.map((item) => <View key={item.title} style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={[styles.icon, { backgroundColor: colors.gold + "18" }]}><Feather name={item.icon} size={21} color={colors.gold} /></View><View style={{ flex: 1 }}><Text style={[styles.cardTitle, { color: colors.foreground }]}>{item.title}</Text><Text style={[styles.cardBody, { color: colors.mutedForeground }]}>{item.body}</Text></View></View>)}</ScrollView></View>;
}
const styles = StyleSheet.create({ root: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingBottom: 12 }, back: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" }, title: { fontFamily: "Inter_700Bold", fontSize: 26 }, subtitle: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 }, card: { borderWidth: 1, borderRadius: 18, padding: 16, flexDirection: "row", gap: 12, marginBottom: 12 }, icon: { width: 44, height: 44, borderRadius: 15, alignItems: "center", justifyContent: "center" }, cardTitle: { fontFamily: "Inter_700Bold", fontSize: 16 }, cardBody: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 20, marginTop: 4 } });
