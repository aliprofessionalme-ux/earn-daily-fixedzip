import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WebView } from "react-native-webview";

import { useColors } from "@/hooks/useColors";
import { useUser } from "@/contexts/UserContext";

const MONLIX_APP_ID = process.env.EXPO_PUBLIC_MONLIX_APP_ID ?? "";

export default function OfferwallScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { deviceId } = useUser();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const offerwallUrl = deviceId && MONLIX_APP_ID
    ? `https://offers.monlix.com/?app=${MONLIX_APP_ID}&user=${encodeURIComponent(deviceId)}`
    : null;

  if (Platform.OS === "web") {
    return (
      <View style={[styles.root, { backgroundColor: colors.background, paddingTop: topPad }]}>
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Offerwalls</Text>
          <Text style={[styles.headerSubtitle, { color: colors.mutedForeground }]}>
            Complete offers to earn coins
          </Text>
        </View>
        <View style={[styles.webPlaceholder, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="smartphone" size={48} color={colors.mutedForeground} />
          <Text style={[styles.webMsg, { color: colors.mutedForeground }]}>
            Open on Android to access the Offerwall
          </Text>
        </View>
      </View>
    );
  }

  if (!offerwallUrl) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background, paddingTop: topPad }]}>
        <View style={[styles.center, { backgroundColor: colors.background }]}>
          <Feather name="alert-circle" size={48} color={colors.mutedForeground} />
          <Text style={[styles.errorMsg, { color: colors.mutedForeground }]}>
            Offerwall not configured
          </Text>
          <Text style={[styles.errorSub, { color: colors.mutedForeground }]}>
            Set EXPO_PUBLIC_MONLIX_APP_ID in your secrets
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: topPad + 12,
            backgroundColor: colors.card,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Offerwalls</Text>
        <Text style={[styles.headerSubtitle, { color: colors.mutedForeground }]}>
          Complete tasks to earn coins
        </Text>
      </View>

      <View style={styles.webviewContainer}>
        <WebView
          source={{ uri: offerwallUrl }}
          style={{ flex: 1, backgroundColor: colors.background }}
          onLoadStart={() => { setLoading(true); setError(false); }}
          onLoadEnd={() => setLoading(false)}
          onError={() => { setLoading(false); setError(true); }}
          javaScriptEnabled
          domStorageEnabled
          startInLoadingState={false}
          allowsFullscreenVideo
        />
        {loading && (
          <View style={[styles.loadingOverlay, { backgroundColor: colors.background }]}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
              Loading offers...
            </Text>
          </View>
        )}
        {error && (
          <View style={[styles.loadingOverlay, { backgroundColor: colors.background }]}>
            <Feather name="wifi-off" size={48} color={colors.destructive} />
            <Text style={[styles.errorMsg, { color: colors.destructive }]}>
              Failed to load
            </Text>
            <Text style={[styles.errorSub, { color: colors.mutedForeground }]}>
              Check your connection
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    padding: 20,
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerTitle: { fontFamily: "Inter_700Bold", fontSize: 24 },
  headerSubtitle: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 2 },
  webviewContainer: { flex: 1, position: "relative" },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  loadingText: { fontFamily: "Inter_400Regular", fontSize: 14 },
  errorMsg: { fontFamily: "Inter_600SemiBold", fontSize: 16, marginTop: 12 },
  errorSub: { fontFamily: "Inter_400Regular", fontSize: 13, textAlign: "center", paddingHorizontal: 32 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  webPlaceholder: {
    margin: 20,
    padding: 40,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: "center",
    gap: 16,
  },
  webMsg: { fontFamily: "Inter_400Regular", fontSize: 15, textAlign: "center" },
});
