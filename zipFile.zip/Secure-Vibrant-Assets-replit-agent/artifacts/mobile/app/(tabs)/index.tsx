import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState, useCallback } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";

import { useColors } from "@/hooks/useColors";
import { useUser } from "@/contexts/UserContext";

function formatCoins(n: number) {
  return n.toLocaleString();
}

function formatPKR(n: number) {
  return "PKR " + n.toFixed(2);
}

function truncateId(id: string) {
  if (id.length <= 16) return id;
  return id.slice(0, 8) + "..." + id.slice(-6);
}

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { deviceId, user, isLoading, error, refreshUser, checkIn } = useUser();
  const [checkInLoading, setCheckInLoading] = useState(false);
  const [checkInMessage, setCheckInMessage] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const handleCheckIn = useCallback(async () => {
    if (!deviceId || checkInLoading) return;
    setCheckInLoading(true);
    setCheckInMessage(null);
    try {
      const result = await checkIn();
      setCheckInMessage(result.message);
      if (result.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        await refreshUser();
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    } catch {
      setCheckInMessage("Something went wrong. Try again.");
    } finally {
      setCheckInLoading(false);
    }
  }, [deviceId, checkInLoading, checkIn]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refreshUser();
    setRefreshing(false);
  }, [refreshUser]);

  const navCards = [
    {
      title: "Mini Games",
      subtitle: "Spin & Scratch",
      icon: "zap" as const,
      gradient: [colors.purple, colors.purpleDark] as [string, string],
      route: "/(tabs)/games" as const,
    },
    {
      title: "Offerwalls",
      subtitle: "Complete tasks",
      icon: "gift" as const,
      gradient: [colors.blue, "#1D4ED8"] as [string, string],
      route: "/(tabs)/offerwall" as const,
    },
    {
      title: "Wallet",
      subtitle: "Withdraw PKR",
      icon: "credit-card" as const,
      gradient: [colors.green, "#047857"] as [string, string],
      route: "/(tabs)/wallet" as const,
    },
    {
      title: "Profile",
      subtitle: "Account tools",
      icon: "user" as const,
      gradient: [colors.gold, colors.orange] as [string, string],
      route: "/(tabs)/profile" as const,
    },
  ];

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
          Setting up your account...
        </Text>
      </View>
    );
  }

  if (error) {
    const isNetworkError = error.includes("unavailable") || error.includes("network");
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Feather name="smartphone" size={48} color={colors.primary} />
        <Text style={[styles.errorText, { color: colors.foreground }]}>
          {isNetworkError ? "Open on Android" : "Connection Error"}
        </Text>
        <Text style={[styles.errorSubText, { color: colors.mutedForeground }]}>
          {isNetworkError
            ? "Scan the QR code with Expo Go on your Android device to use the full app"
            : error}
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={{ paddingTop: topPad, paddingBottom: Platform.OS === "web" ? 34 : 100 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <LinearGradient
          colors={["#1A0A3A", "#0D0D1A"]}
          style={styles.headerGradient}
        >
          <View style={styles.headerTop}>
            <View>
              <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
                Account ID
              </Text>
              <Text style={[styles.deviceId, { color: colors.purpleLight }]}>
                {deviceId ? truncateId(deviceId) : "—"}
              </Text>
            </View>
            <Pressable
              onPress={onRefresh}
              style={({ pressed }) => [styles.refreshBtn, { opacity: pressed ? 0.6 : 1 }]}
            >
              <Feather name="refresh-cw" size={20} color={colors.mutedForeground} />
            </Pressable>
          </View>

          {/* Balance Cards */}
          <View style={styles.balanceRow}>
            <LinearGradient
              colors={["#2D1B69", "#1A0A3A"]}
              style={[styles.balanceCard, { borderColor: colors.purpleLight + "30" }]}
            >
              <Feather name="star" size={20} color={colors.gold} />
              <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>
                Coins
              </Text>
              <Text style={[styles.balanceValue, { color: colors.gold }]}>
                {formatCoins(user?.coinsBalance ?? 0)}
              </Text>
            </LinearGradient>

            <LinearGradient
              colors={["#064E3B", "#0D0D1A"]}
              style={[styles.balanceCard, { borderColor: colors.green + "30" }]}
            >
              <Feather name="dollar-sign" size={20} color={colors.green} />
              <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>
                PKR Balance
              </Text>
              <Text style={[styles.balanceValue, { color: colors.green }]}>
                {formatPKR(user?.pkrBalance ?? 0)}
              </Text>
            </LinearGradient>
          </View>

          <Text style={[styles.rateNote, { color: colors.mutedForeground }]}>
            1,000 coins = PKR 20
          </Text>
        </LinearGradient>

        {/* Daily Check-In */}
        <View style={styles.section}>
          <Pressable
            onPress={handleCheckIn}
            disabled={checkInLoading}
            style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}
          >
            <LinearGradient
              colors={[colors.gold, colors.orange]}
              style={styles.checkInBtn}
            >
              {checkInLoading ? (
                <ActivityIndicator color="#000" size="small" />
              ) : (
                <Feather name="sun" size={24} color="#000" />
              )}
              <Text style={styles.checkInText}>
                {checkInLoading ? "Claiming..." : "Daily Check-In  +50 Coins"}
              </Text>
            </LinearGradient>
          </Pressable>
          {checkInMessage ? (
            <Text
              style={[
                styles.checkInMsg,
                {
                  color: checkInMessage.includes("successful")
                    ? colors.green
                    : colors.mutedForeground,
                },
              ]}
            >
              {checkInMessage}
            </Text>
          ) : null}
        </View>

        {/* Navigation Cards */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Earn More Coins
          </Text>
          <View style={styles.navGrid}>
            {navCards.map((card) => (
              <Pressable
                key={card.title}
                onPress={() => {
                  Haptics.selectionAsync();
                  router.push(card.route);
                }}
                style={({ pressed }) => ({
                  width: "100%",
                  opacity: pressed ? 0.85 : 1,
                  transform: [{ scale: pressed ? 0.99 : 1 }],
                })}
              >
                <LinearGradient
                  colors={card.gradient}
                  style={[styles.navCard, { borderColor: card.gradient[0] + "40" }]}
                >
                  <Feather name={card.icon} size={26} color="#fff" />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.navCardTitle}>{card.title}</Text>
                    <Text style={styles.navCardSubtitle}>{card.subtitle}</Text>
                  </View>
                  <Feather name="chevron-right" size={20} color="rgba(255,255,255,0.7)" />
                </LinearGradient>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Stats */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Today's Activity
          </Text>
          <View
            style={[styles.statsCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <StatRow
              icon="zap"
              label="Spins Used"
              value={`${user?.dailySpinsUsed ?? 0} / 5`}
              color={colors.purple}
              colors={colors}
            />
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
            <StatRow
              icon="layers"
              label="Scratches Used"
              value={`${user?.dailyScratchUsed ?? 0} / 5`}
              color={colors.blue}
              colors={colors}
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function StatRow({
  icon,
  label,
  value,
  color,
  colors,
}: {
  icon: React.ComponentProps<typeof Feather>["name"];
  label: string;
  value: string;
  color: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={styles.statRow}>
      <View style={[styles.statIcon, { backgroundColor: color + "20" }]}>
        <Feather name={icon} size={16} color={color} />
      </View>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  loadingText: { fontFamily: "Inter_400Regular", fontSize: 16, marginTop: 8 },
  errorText: { fontFamily: "Inter_700Bold", fontSize: 18, marginTop: 16 },
  errorSubText: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", paddingHorizontal: 32 },
  headerGradient: { padding: 20, paddingBottom: 24 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 },
  greeting: { fontFamily: "Inter_400Regular", fontSize: 12, letterSpacing: 0.5 },
  deviceId: { fontFamily: "Inter_600SemiBold", fontSize: 14, marginTop: 2 },
  refreshBtn: { padding: 8 },
  balanceRow: { flexDirection: "row", gap: 12 },
  balanceCard: {
    flex: 1,
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 8,
  },
  balanceLabel: { fontFamily: "Inter_400Regular", fontSize: 12 },
  balanceValue: { fontFamily: "Inter_700Bold", fontSize: 24 },
  rateNote: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 12, textAlign: "center" },
  section: { padding: 20, paddingTop: 0, marginTop: 20 },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, marginBottom: 12 },
  checkInBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    padding: 18,
    borderRadius: 16,
  },
  checkInText: { fontFamily: "Inter_700Bold", fontSize: 16, color: "#000" },
  checkInMsg: { fontFamily: "Inter_400Regular", fontSize: 13, textAlign: "center", marginTop: 10 },
  navGrid: { gap: 12 },
  navCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  navCardTitle: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#fff" },
  navCardSubtitle: { fontFamily: "Inter_400Regular", fontSize: 12, color: "rgba(255,255,255,0.7)" },
  statsCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  statRow: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12 },
  statIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  statLabel: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 14 },
  statValue: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  divider: { height: 1, marginHorizontal: 16 },
});
