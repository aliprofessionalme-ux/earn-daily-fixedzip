import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useUser } from "@/contexts/UserContext";
import { getTransactions, type TransactionDocument } from "@/services/api";

function titleFor(type: string) {
  return type.replace(/_/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
}
function formatDate(ts: string) {
  try { return new Date(ts).toLocaleString("en-PK", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); } catch { return "—"; }
}
function signed(n: number, suffix = "") { return `${n > 0 ? "+" : ""}${n}${suffix}`; }

export default function TransactionsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { deviceId } = useUser();
  const [items, setItems] = useState<TransactionDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const topPad = Platform.OS === "web" ? 28 : insets.top + 8;

  const load = useCallback(async () => {
    if (!deviceId) return;
    setLoading(true); setError(null);
    try { setItems(await getTransactions(deviceId)); }
    catch (err) { setError(err instanceof Error ? err.message : "Unable to load transactions."); }
    finally { setLoading(false); }
  }, [deviceId]);

  useEffect(() => { void load(); }, [load]);

  return (
    <View style={[styles.root, { backgroundColor: colors.background, paddingTop: topPad }]}> 
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name="arrow-left" size={20} color={colors.foreground} /></Pressable>
        <View style={{ flex: 1 }}><Text style={[styles.title, { color: colors.foreground }]}>Transactions</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>All balance changes from rewards, offers, withdrawals and admin actions</Text></View>
      </View>
      {loading ? <View style={styles.center}><ActivityIndicator color={colors.primary} /><Text style={[styles.empty, { color: colors.mutedForeground }]}>Loading history...</Text></View> : error ? <View style={styles.center}><Feather name="alert-circle" size={42} color={colors.destructive} /><Text style={[styles.empty, { color: colors.destructive }]}>{error}</Text><Pressable onPress={load} style={[styles.retry, { backgroundColor: colors.primary }]}><Text style={styles.retryText}>Retry</Text></Pressable></View> : items.length === 0 ? <View style={styles.center}><Feather name="inbox" size={46} color={colors.mutedForeground} /><Text style={[styles.empty, { color: colors.mutedForeground }]}>No transactions yet</Text></View> : (
        <FlatList data={items} keyExtractor={(item) => item.transactionId} contentContainerStyle={{ padding: 18, paddingBottom: 36 }} renderItem={({ item }) => (
          <View style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border }]}> 
            <View style={[styles.icon, { backgroundColor: (item.coinsChange >= 0 ? colors.green : colors.destructive) + "18" }]}><Feather name={item.coinsChange >= 0 ? "plus" : "minus"} size={18} color={item.coinsChange >= 0 ? colors.green : colors.destructive} /></View>
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={[styles.rowTitle, { color: colors.foreground }]}>{titleFor(item.type)}</Text>
              <Text style={[styles.rowSub, { color: colors.mutedForeground }]}>{formatDate(item.createdAt)} · {item.status}</Text>
              {typeof item.balanceAfterCoins === "number" ? <Text style={[styles.rowSub, { color: colors.mutedForeground }]}>Balance after: {item.balanceAfterCoins.toLocaleString()} coins · PKR {Number(item.balanceAfterPKR ?? 0).toFixed(2)}</Text> : null}
            </View>
            <View style={styles.amounts}>
              <Text style={[styles.coins, { color: item.coinsChange >= 0 ? colors.green : colors.destructive }]}>{signed(item.coinsChange)}</Text>
              {item.pkrChange ? <Text style={[styles.pkr, { color: colors.mutedForeground }]}>{signed(Number(item.pkrChange.toFixed(2)), " PKR")}</Text> : null}
            </View>
          </View>
        )} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({ root: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 18, paddingBottom: 12 }, back: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" }, title: { fontFamily: "Inter_700Bold", fontSize: 26 }, subtitle: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2, lineHeight: 17 }, center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, padding: 24 }, empty: { fontFamily: "Inter_500Medium", fontSize: 14, textAlign: "center" }, retry: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 }, retryText: { color: "#fff", fontFamily: "Inter_700Bold" }, row: { borderWidth: 1, borderRadius: 18, padding: 14, marginBottom: 10, flexDirection: "row", gap: 12, alignItems: "flex-start" }, icon: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, rowTitle: { fontFamily: "Inter_700Bold", fontSize: 15 }, rowSub: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 16, marginTop: 2 }, amounts: { alignItems: "flex-end", gap: 2 }, coins: { fontFamily: "Inter_700Bold", fontSize: 15 }, pkr: { fontFamily: "Inter_500Medium", fontSize: 11 } });
