import admin from "firebase-admin";
import { logger } from "../lib/logger.js";

let initialized = false;

export class HttpError extends Error {
  status: number;
  code: string;

  constructor(status: number, message: string, code = "request_failed") {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function handleRouteError(err: unknown, fallback = "Request failed") {
  if (err instanceof HttpError) {
    return { status: err.status, body: { error: err.message, code: err.code } };
  }
  const message = err instanceof Error ? err.message : fallback;
  if (message.includes("Firebase") || message.includes("FIREBASE")) {
    return {
      status: 500,
      body: {
        error: "Backend Firebase configuration is missing or invalid. Check FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL and FIREBASE_PRIVATE_KEY.",
        code: "firebase_config_missing",
      },
    };
  }
  return { status: 500, body: { error: fallback, code: "internal_error" } };
}

function getFirebaseAdminApp() {
  if (!initialized) {
    const projectId = process.env["FIREBASE_PROJECT_ID"];
    const clientEmail = process.env["FIREBASE_CLIENT_EMAIL"];
    const privateKey = process.env["FIREBASE_PRIVATE_KEY"]?.replace(/\\n/g, "\n");

    if (!projectId) {
      logger.warn("FIREBASE_PROJECT_ID not set — Firestore operations will fail until configured");
    }

    if (admin.apps.length === 0) {
      if (clientEmail && privateKey && projectId) {
        admin.initializeApp({
          credential: admin.credential.cert({ projectId, clientEmail, privateKey }),
        });
      } else {
        admin.initializeApp(projectId ? { projectId } : undefined);
      }
    }

    initialized = true;
  }

  return admin.app();
}

export function getFirestoreDb() {
  getFirebaseAdminApp();
  return admin.firestore();
}

export async function verifyFirebaseToken(firebaseToken?: string | null) {
  if (!firebaseToken) return null;
  getFirebaseAdminApp();
  try {
    return await admin.auth().verifyIdToken(firebaseToken);
  } catch {
    return null;
  }
}

export function nowTs() {
  return admin.firestore.Timestamp.now();
}

export function coinsToPKR(coins: number): number {
  return Number(((coins / 1000) * 20).toFixed(2));
}

export function pkrToCoins(pkr: number): number {
  return Math.round((pkr / 20) * 1000);
}

export function getTodayString(): string {
  return new Date().toISOString().split("T")[0];
}

export function getCurrentMonthString(): string {
  return new Date().toISOString().slice(0, 7);
}

export interface AppSettings {
  coinRateCoins: number;
  coinRatePKR: number;
  minimumWithdrawalPKR: number;
  spinDailyLimit: number;
  scratchDailyLimit: number;
  checkInCoins: number;
  withdrawalDayText: string;
  maintenanceMode: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  coinRateCoins: 1000,
  coinRatePKR: 20,
  minimumWithdrawalPKR: 500,
  spinDailyLimit: 5,
  scratchDailyLimit: 5,
  checkInCoins: 50,
  withdrawalDayText: "Withdrawals are reviewed manually before payout.",
  maintenanceMode: false,
};

export interface FirestoreUser {
  deviceId: string;
  installId: string | null;
  deviceFingerprint: string | null;
  deviceInfo: Record<string, unknown> | null;
  firebaseUid: string | null;
  authMode: "firebase-anonymous" | "device-only";
  authVerified: boolean;
  coinsBalance: number;
  pkrBalance: number;
  lastCheckInTimestamp: admin.firestore.Timestamp | null;
  dailySpinsUsed: number;
  dailyScratchUsed: number;
  lastSpinResetDate: string | null;
  lastScratchResetDate: string | null;
  isBanned: boolean;
  banReason: string | null;
  bannedAt: admin.firestore.Timestamp | null;
  suspiciousScore: number;
  fraudFlags: string[];
  createdAt: admin.firestore.Timestamp;
  updatedAt: admin.firestore.Timestamp;
  lastActiveAt: admin.firestore.Timestamp;
}

export interface InitUserInput {
  deviceId: string;
  installId?: string | null;
  deviceFingerprint?: string | null;
  firebaseUid?: string | null;
  firebaseToken?: string | null;
  authMode?: "firebase-anonymous" | "device-only";
  authVerified?: boolean;
  deviceInfo?: Record<string, unknown> | null;
}

export type LedgerType =
  | "checkin"
  | "spin"
  | "scratch"
  | "offerwall"
  | "withdrawal_hold"
  | "withdrawal_refund"
  | "admin_adjustment";

export interface WithdrawalDocument {
  withdrawalId: string;
  deviceId: string;
  paymentMethod: "Easypaisa" | "JazzCash";
  accountNumber: string;
  accountTitle: string;
  amountPKR: number;
  coinsDeducted: number;
  status: "pending" | "approved" | "rejected" | "paid";
  adminNote: string | null;
  rejectionReason: string | null;
  createdMonth: string;
  createdAt: admin.firestore.Timestamp;
  updatedAt: admin.firestore.Timestamp;
  processedAt: admin.firestore.Timestamp | null;
  paidAt: admin.firestore.Timestamp | null;
}

export async function getAppSettings(): Promise<AppSettings> {
  const db = getFirestoreDb();
  const snap = await db.collection("settings").doc("app").get();
  if (!snap.exists) return DEFAULT_SETTINGS;
  return { ...DEFAULT_SETTINGS, ...(snap.data() as Partial<AppSettings>) };
}

function baseUser(input: InitUserInput): FirestoreUser {
  const now = nowTs();
  const today = getTodayString();
  return {
    deviceId: input.deviceId,
    installId: input.installId ?? null,
    deviceFingerprint: input.deviceFingerprint ?? null,
    deviceInfo: input.deviceInfo ?? null,
    firebaseUid: input.firebaseUid ?? null,
    authMode: input.authMode ?? "device-only",
    authVerified: Boolean(input.authVerified),
    coinsBalance: 0,
    pkrBalance: 0,
    lastCheckInTimestamp: null,
    dailySpinsUsed: 0,
    dailyScratchUsed: 0,
    lastSpinResetDate: today,
    lastScratchResetDate: today,
    isBanned: false,
    banReason: null,
    bannedAt: null,
    suspiciousScore: 0,
    fraudFlags: [],
    createdAt: now,
    updatedAt: now,
    lastActiveAt: now,
  };
}

export function serializeTimestamp(value: unknown): unknown {
  if (value && typeof value === "object" && "toDate" in value && typeof (value as { toDate: () => Date }).toDate === "function") {
    return (value as { toDate: () => Date }).toDate().toISOString();
  }
  return value ?? null;
}

export function serializeDoc<T extends Record<string, unknown>>(data: T) {
  return Object.fromEntries(Object.entries(data).map(([key, value]) => [key, serializeTimestamp(value)]));
}

export function serializeUser(user: FirestoreUser) {
  return serializeDoc(user as unknown as Record<string, unknown>);
}

function mergeSafeUserMetadata(existing: Partial<FirestoreUser>, input: InitUserInput): Partial<FirestoreUser> {
  const update: Partial<FirestoreUser> = {
    lastActiveAt: nowTs(),
    updatedAt: nowTs(),
  };

  if (!existing.installId && input.installId) update.installId = input.installId;
  if (!existing.deviceFingerprint && input.deviceFingerprint) update.deviceFingerprint = input.deviceFingerprint;
  if (!existing.firebaseUid && input.firebaseUid) update.firebaseUid = input.firebaseUid;
  if (input.authMode) update.authMode = input.authMode;
  if (typeof input.authVerified === "boolean") update.authVerified = input.authVerified;
  if (input.deviceInfo) update.deviceInfo = input.deviceInfo;

  return update;
}

export async function initUser(input: InitUserInput): Promise<{ user: FirestoreUser; duplicateRestored: boolean; authWarning?: string }> {
  const db = getFirestoreDb();
  const verifiedToken = await verifyFirebaseToken(input.firebaseToken);
  const authWarning = input.firebaseToken && !verifiedToken ? "Firebase token verification failed; using device identity fallback." : undefined;

  const normalized: InitUserInput = {
    ...input,
    firebaseUid: verifiedToken?.uid ?? input.firebaseUid ?? null,
    authMode: verifiedToken ? "firebase-anonymous" : input.authMode ?? "device-only",
    authVerified: Boolean(verifiedToken) || Boolean(input.authVerified && input.authMode === "firebase-anonymous"),
  };

  let duplicateRestored = false;
  const ref = db.collection("users").doc(normalized.deviceId);
  const snap = await ref.get();

  if (snap.exists) {
    const existing = snap.data() as FirestoreUser;
    await ref.set(mergeSafeUserMetadata(existing, normalized), { merge: true });
    const updated = await ref.get();
    return { user: updated.data() as FirestoreUser, duplicateRestored, authWarning };
  }

  if (normalized.deviceFingerprint) {
    const dup = await db
      .collection("users")
      .where("deviceFingerprint", "==", normalized.deviceFingerprint)
      .limit(1)
      .get();
    if (!dup.empty) {
      const dupRef = dup.docs[0].ref;
      const existing = dup.docs[0].data() as FirestoreUser;
      await dupRef.set(
        {
          ...mergeSafeUserMetadata(existing, normalized),
          suspiciousScore: Math.max(existing.suspiciousScore ?? 0, 1),
          fraudFlags: Array.from(new Set([...(existing.fraudFlags ?? []), "duplicate_device_fingerprint"])),
          duplicateDeviceIds: admin.firestore.FieldValue.arrayUnion(normalized.deviceId),
        },
        { merge: true },
      );
      duplicateRestored = true;
      const updated = await dupRef.get();
      return { user: updated.data() as FirestoreUser, duplicateRestored, authWarning };
    }
  }

  const user = baseUser(normalized);
  await ref.set(user);
  return { user, duplicateRestored, authWarning };
}

export async function getUserDoc(deviceId: string): Promise<FirestoreUser | null> {
  const snap = await getFirestoreDb().collection("users").doc(deviceId).get();
  return snap.exists ? (snap.data() as FirestoreUser) : null;
}

export async function requireUser(tx: admin.firestore.Transaction, deviceId: string) {
  const ref = getFirestoreDb().collection("users").doc(deviceId);
  const snap = await tx.get(ref);
  if (!snap.exists) throw new HttpError(404, "User not found", "user_not_found");
  const user = snap.data() as FirestoreUser;
  if (user.isBanned) throw new HttpError(403, user.banReason ? `Account banned: ${user.banReason}` : "Account banned", "user_banned");
  return { ref, user };
}

export function randomId(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function ledgerRef(transactionId?: string) {
  const db = getFirestoreDb();
  return transactionId ? db.collection("coinTransactions").doc(transactionId) : db.collection("coinTransactions").doc();
}

function ledgerPayload(params: {
  transactionId: string;
  deviceId: string;
  type: LedgerType;
  coinsChange: number;
  pkrChange: number;
  balanceAfterCoins: number;
  balanceAfterPKR: number;
  source: string;
  status: string;
  metadata?: Record<string, unknown>;
}) {
  return {
    transactionId: params.transactionId,
    deviceId: params.deviceId,
    type: params.type,
    coinsChange: params.coinsChange,
    pkrChange: Number(params.pkrChange.toFixed(2)),
    balanceAfterCoins: params.balanceAfterCoins,
    balanceAfterPKR: Number(params.balanceAfterPKR.toFixed(2)),
    source: params.source,
    status: params.status,
    metadata: params.metadata ?? {},
    createdAt: nowTs(),
  };
}

export async function creditCheckIn(deviceId: string) {
  const settings = await getAppSettings();
  const db = getFirestoreDb();

  return db.runTransaction(async (tx) => {
    const { ref, user } = await requireUser(tx, deviceId);
    if (user.lastCheckInTimestamp) {
      const hoursSince = (Date.now() - user.lastCheckInTimestamp.toDate().getTime()) / 3600000;
      if (hoursSince < 24) throw new HttpError(400, "Check-in is available once every 24 hours.", "checkin_not_ready");
    }

    const coinsAwarded = settings.checkInCoins;
    const balanceAfterCoins = user.coinsBalance + coinsAwarded;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(ref, {
      coinsBalance: balanceAfterCoins,
      pkrBalance: balanceAfterPKR,
      lastCheckInTimestamp: nowTs(),
      updatedAt: nowTs(),
      lastActiveAt: nowTs(),
    });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId,
      type: "checkin",
      coinsChange: coinsAwarded,
      pkrChange: coinsToPKR(coinsAwarded),
      balanceAfterCoins,
      balanceAfterPKR,
      source: "checkin",
      status: "credited",
    }));

    return { success: true, message: `Check-in successful! +${coinsAwarded} coins`, coinsAwarded, balanceAfterCoins, balanceAfterPKR };
  });
}

export const SPIN_REWARDS = [5, 10, 20, 25, 50, 100] as const;
export const SPIN_WEIGHTS = [30, 25, 20, 12, 10, 3] as const;
export const SCRATCH_REWARDS = [10, 15, 20, 25, 30, 50] as const;
export const SCRATCH_WEIGHTS = [28, 25, 22, 14, 8, 3] as const;

function weightedReward(rewards: readonly number[], weights: readonly number[]) {
  const total = weights.reduce((sum, weight) => sum + weight, 0);
  let roll = Math.random() * total;
  for (let i = 0; i < rewards.length; i += 1) {
    roll -= weights[i];
    if (roll <= 0) return rewards[i];
  }
  return rewards[0];
}

export async function creditSpin(deviceId: string) {
  const settings = await getAppSettings();
  const coinsAwarded = weightedReward(SPIN_REWARDS, SPIN_WEIGHTS);
  const db = getFirestoreDb();
  const today = getTodayString();

  return db.runTransaction(async (tx) => {
    const { ref, user } = await requireUser(tx, deviceId);
    const spinsUsed = user.lastSpinResetDate === today ? user.dailySpinsUsed ?? 0 : 0;
    if (spinsUsed >= settings.spinDailyLimit) {
      throw new HttpError(400, `Daily spin limit reached (${settings.spinDailyLimit}/${settings.spinDailyLimit}).`, "daily_spin_limit_reached");
    }

    const balanceAfterCoins = user.coinsBalance + coinsAwarded;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(ref, {
      coinsBalance: balanceAfterCoins,
      pkrBalance: balanceAfterPKR,
      dailySpinsUsed: spinsUsed + 1,
      lastSpinResetDate: today,
      updatedAt: nowTs(),
      lastActiveAt: nowTs(),
    });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId,
      type: "spin",
      coinsChange: coinsAwarded,
      pkrChange: coinsToPKR(coinsAwarded),
      balanceAfterCoins,
      balanceAfterPKR,
      source: "spin",
      status: "credited",
      metadata: { dailySpinLimit: settings.spinDailyLimit, rewardSegments: SPIN_REWARDS },
    }));

    return {
      success: true,
      message: `You won ${coinsAwarded} coins!`,
      coinsAwarded,
      rewardSegment: coinsAwarded,
      spinsLeft: settings.spinDailyLimit - (spinsUsed + 1),
      balanceAfterCoins,
      balanceAfterPKR,
    };
  });
}

export async function creditScratch(deviceId: string) {
  const settings = await getAppSettings();
  const coinsAwarded = weightedReward(SCRATCH_REWARDS, SCRATCH_WEIGHTS);
  const db = getFirestoreDb();
  const today = getTodayString();

  return db.runTransaction(async (tx) => {
    const { ref, user } = await requireUser(tx, deviceId);
    const scratchesUsed = user.lastScratchResetDate === today ? user.dailyScratchUsed ?? 0 : 0;
    if (scratchesUsed >= settings.scratchDailyLimit) {
      throw new HttpError(400, `Daily scratch limit reached (${settings.scratchDailyLimit}/${settings.scratchDailyLimit}).`, "daily_scratch_limit_reached");
    }

    const balanceAfterCoins = user.coinsBalance + coinsAwarded;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(ref, {
      coinsBalance: balanceAfterCoins,
      pkrBalance: balanceAfterPKR,
      dailyScratchUsed: scratchesUsed + 1,
      lastScratchResetDate: today,
      updatedAt: nowTs(),
      lastActiveAt: nowTs(),
    });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId,
      type: "scratch",
      coinsChange: coinsAwarded,
      pkrChange: coinsToPKR(coinsAwarded),
      balanceAfterCoins,
      balanceAfterPKR,
      source: "scratch",
      status: "credited",
      metadata: { dailyScratchLimit: settings.scratchDailyLimit, rewardSegments: SCRATCH_REWARDS },
    }));

    return { success: true, message: `You won ${coinsAwarded} coins!`, coinsAwarded, scratchLeft: settings.scratchDailyLimit - (scratchesUsed + 1), balanceAfterCoins, balanceAfterPKR };
  });
}

export async function submitWithdrawal(deviceId: string, input: {
  paymentMethod: "Easypaisa" | "JazzCash";
  accountNumber: string;
  accountTitle: string;
  amountPKR: number;
}) {
  const settings = await getAppSettings();
  if (input.amountPKR < settings.minimumWithdrawalPKR) {
    throw new HttpError(400, `Minimum withdrawal is PKR ${settings.minimumWithdrawalPKR}.`, "minimum_withdrawal_not_met");
  }

  const db = getFirestoreDb();
  const createdMonth = getCurrentMonthString();

  return db.runTransaction(async (tx) => {
    const { ref, user } = await requireUser(tx, deviceId);
    if (user.pkrBalance < input.amountPKR) throw new HttpError(400, "You cannot withdraw more than your available balance.", "insufficient_balance");

    const pendingQuery = db.collection("withdrawals").where("deviceId", "==", deviceId).where("status", "==", "pending").limit(1);
    const pendingSnap = await tx.get(pendingQuery);
    if (!pendingSnap.empty) throw new HttpError(400, "You already have a pending withdrawal request.", "pending_withdrawal_exists");

    const monthlyQuery = db.collection("withdrawals").where("deviceId", "==", deviceId).where("createdMonth", "==", createdMonth).limit(1);
    const monthlySnap = await tx.get(monthlyQuery);
    if (!monthlySnap.empty) throw new HttpError(400, "Monthly withdrawal limit reached. You can submit one withdrawal per calendar month.", "monthly_withdrawal_limit_reached");

    const coinsDeducted = pkrToCoins(input.amountPKR);
    if (user.coinsBalance < coinsDeducted) throw new HttpError(400, "Insufficient coin balance for this withdrawal.", "insufficient_balance");

    const balanceAfterCoins = user.coinsBalance - coinsDeducted;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const withdrawalId = randomId("wd");
    const withdrawalRef = db.collection("withdrawals").doc(withdrawalId);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(ref, { coinsBalance: balanceAfterCoins, pkrBalance: balanceAfterPKR, updatedAt: nowTs(), lastActiveAt: nowTs() });
    tx.set(withdrawalRef, {
      withdrawalId,
      deviceId,
      paymentMethod: input.paymentMethod,
      accountNumber: input.accountNumber.trim(),
      accountTitle: input.accountTitle.trim(),
      amountPKR: input.amountPKR,
      coinsDeducted,
      status: "pending",
      adminNote: null,
      rejectionReason: null,
      createdMonth,
      createdAt: nowTs(),
      updatedAt: nowTs(),
      processedAt: null,
      paidAt: null,
    } satisfies WithdrawalDocument);
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId,
      type: "withdrawal_hold",
      coinsChange: -coinsDeducted,
      pkrChange: -input.amountPKR,
      balanceAfterCoins,
      balanceAfterPKR,
      source: "withdrawal",
      status: "held",
      metadata: { withdrawalId, amountPKR: input.amountPKR },
    }));

    return { success: true, message: "Withdrawal request submitted successfully.", withdrawalId, coinsDeducted, balanceAfterCoins, balanceAfterPKR };
  });
}

export async function rejectWithdrawal(withdrawalId: string, reason: string) {
  const db = getFirestoreDb();
  return db.runTransaction(async (tx) => {
    const withdrawalRef = db.collection("withdrawals").doc(withdrawalId);
    const snap = await tx.get(withdrawalRef);
    if (!snap.exists) throw new HttpError(404, "Withdrawal not found.", "withdrawal_not_found");
    const withdrawal = snap.data() as WithdrawalDocument;
    if (withdrawal.status === "rejected") return { success: true, message: "Withdrawal was already rejected." };
    if (withdrawal.status === "paid") throw new HttpError(400, "Paid withdrawals cannot be rejected.", "withdrawal_already_paid");

    const userRef = db.collection("users").doc(withdrawal.deviceId);
    const userSnap = await tx.get(userRef);
    if (!userSnap.exists) throw new HttpError(404, "User not found.", "user_not_found");
    const user = userSnap.data() as FirestoreUser;
    const balanceAfterCoins = user.coinsBalance + withdrawal.coinsDeducted;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(userRef, { coinsBalance: balanceAfterCoins, pkrBalance: balanceAfterPKR, updatedAt: nowTs() });
    tx.update(withdrawalRef, { status: "rejected", rejectionReason: reason, updatedAt: nowTs(), processedAt: nowTs() });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId: withdrawal.deviceId,
      type: "withdrawal_refund",
      coinsChange: withdrawal.coinsDeducted,
      pkrChange: withdrawal.amountPKR,
      balanceAfterCoins,
      balanceAfterPKR,
      source: "admin",
      status: "refunded",
      metadata: { withdrawalId, reason },
    }));
    return { success: true, message: "Withdrawal rejected and coins refunded." };
  });
}

export async function markWithdrawalStatus(withdrawalId: string, status: "approved" | "paid", adminNote?: string) {
  const db = getFirestoreDb();
  const ref = db.collection("withdrawals").doc(withdrawalId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpError(404, "Withdrawal not found.", "withdrawal_not_found");
  const data = snap.data() as WithdrawalDocument;
  if (data.status === "rejected") throw new HttpError(400, "Rejected withdrawals cannot be approved or paid.", "withdrawal_rejected");
  await ref.update({
    status,
    adminNote: adminNote ?? data.adminNote ?? null,
    updatedAt: nowTs(),
    processedAt: status === "approved" ? nowTs() : data.processedAt ?? nowTs(),
    paidAt: status === "paid" ? nowTs() : data.paidAt ?? null,
  });
  return { success: true, message: status === "paid" ? "Withdrawal marked as paid." : "Withdrawal approved." };
}

export async function adjustUserCoins(deviceId: string, coinsChange: number, reason: string) {
  const db = getFirestoreDb();
  return db.runTransaction(async (tx) => {
    const userRef = db.collection("users").doc(deviceId);
    const snap = await tx.get(userRef);
    if (!snap.exists) throw new HttpError(404, "User not found.", "user_not_found");
    const user = snap.data() as FirestoreUser;
    const balanceAfterCoins = Math.max(0, user.coinsBalance + coinsChange);
    const actualChange = balanceAfterCoins - user.coinsBalance;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(userRef, { coinsBalance: balanceAfterCoins, pkrBalance: balanceAfterPKR, updatedAt: nowTs() });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId,
      type: "admin_adjustment",
      coinsChange: actualChange,
      pkrChange: coinsToPKR(actualChange),
      balanceAfterCoins,
      balanceAfterPKR,
      source: "admin",
      status: "adjusted",
      metadata: { reason },
    }));
    return { success: true, message: "Coins adjusted.", balanceAfterCoins, balanceAfterPKR };
  });
}

export async function creditOfferwallReward(params: { deviceId: string; rewardAmount: number; externalTransactionId: string; source: string; payload?: Record<string, unknown> }) {
  const db = getFirestoreDb();
  const dedupeId = encodeURIComponent(`${params.source}:${params.externalTransactionId}`).replace(/%/g, "_");
  const webhookRef = db.collection("webhookLogs").doc(dedupeId);

  return db.runTransaction(async (tx) => {
    const existing = await tx.get(webhookRef);
    if (existing.exists) {
      tx.set(webhookRef, { duplicate: true, lastSeenAt: nowTs(), attempts: admin.firestore.FieldValue.increment(1) }, { merge: true });
      return { success: true, duplicate: true, message: "Duplicate webhook ignored." };
    }

    const userRef = db.collection("users").doc(params.deviceId);
    const userSnap = await tx.get(userRef);
    if (!userSnap.exists) {
      tx.set(webhookRef, { processed: false, rejected: true, reason: "user_not_found", createdAt: nowTs(), payload: params.payload ?? {} });
      throw new HttpError(404, "User not found.", "user_not_found");
    }
    const user = userSnap.data() as FirestoreUser;
    if (user.isBanned) {
      tx.set(webhookRef, { processed: false, rejected: true, reason: "user_banned", createdAt: nowTs(), payload: params.payload ?? {} });
      throw new HttpError(403, "Account banned. Reward credit blocked.", "user_banned");
    }

    const balanceAfterCoins = user.coinsBalance + params.rewardAmount;
    const balanceAfterPKR = coinsToPKR(balanceAfterCoins);
    const txRef = ledgerRef();
    const transactionId = txRef.id;

    tx.update(userRef, { coinsBalance: balanceAfterCoins, pkrBalance: balanceAfterPKR, updatedAt: nowTs(), lastActiveAt: nowTs() });
    tx.set(txRef, ledgerPayload({
      transactionId,
      deviceId: params.deviceId,
      type: "offerwall",
      coinsChange: params.rewardAmount,
      pkrChange: coinsToPKR(params.rewardAmount),
      balanceAfterCoins,
      balanceAfterPKR,
      source: params.source,
      status: "credited",
      metadata: { externalTransactionId: params.externalTransactionId },
    }));
    tx.set(webhookRef, { processed: true, duplicate: false, rejected: false, failed: false, transactionId, externalTransactionId: params.externalTransactionId, deviceId: params.deviceId, rewardAmount: params.rewardAmount, source: params.source, payload: params.payload ?? {}, createdAt: nowTs(), updatedAt: nowTs(), attempts: 1 });

    return { success: true, duplicate: false, message: "Reward credited successfully.", balanceAfterCoins, balanceAfterPKR };
  }).catch(async (err) => {
    if (!(err instanceof HttpError)) {
      await webhookRef.set({ processed: false, duplicate: false, failed: true, error: err instanceof Error ? err.message : String(err), payload: params.payload ?? {}, updatedAt: nowTs() }, { merge: true });
    }
    throw err;
  });
}
