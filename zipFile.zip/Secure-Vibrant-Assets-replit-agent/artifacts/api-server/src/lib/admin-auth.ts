import { randomBytes, createHash, timingSafeEqual } from "node:crypto";

const sessions = new Map<string, number>();

function secretValue() {
  const value = process.env["ADMIN_PASSWORD"];
  if (!value) throw new Error("ADMIN_PASSWORD is required");
  return value;
}

function sessionSecret() {
  return process.env["SESSION_SECRET"] ?? "dev-session-secret";
}

export function validateAdminPassword(input: string) {
  const expected = Buffer.from(secretValue());
  const actual = Buffer.from(input);
  if (expected.length !== actual.length) return false;
  return timingSafeEqual(expected, actual);
}

export function createAdminSession() {
  const token = randomBytes(32).toString("hex");
  const hash = createHash("sha256").update(`${token}:${sessionSecret()}`).digest("hex");
  sessions.set(hash, Date.now() + 1000 * 60 * 60 * 12);
  return token;
}

export function isAdminSession(token?: string) {
  if (!token) return false;
  const hash = createHash("sha256").update(`${token}:${sessionSecret()}`).digest("hex");
  const expiry = sessions.get(hash);
  if (!expiry) return false;
  if (expiry < Date.now()) {
    sessions.delete(hash);
    return false;
  }
  return true;
}
