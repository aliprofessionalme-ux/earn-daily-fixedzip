import { Router } from "express";
import {
  adjustUserCoins,
  getAppSettings,
  getFirestoreDb,
  handleRouteError,
  markWithdrawalStatus,
  rejectWithdrawal,
  serializeDoc,
  nowTs,
} from "../services/firebase-admin.js";
import { createAdminSession, isAdminSession, validateAdminPassword } from "../lib/admin-auth.js";

export const adminPanelRouter = Router();
export const adminApiRouter = Router();

function adminShell(content: string) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title><style>body{margin:0;font-family:Inter,Arial,sans-serif;background:#080814;color:#fff}a,input,button,textarea{font:inherit}.wrap{max-width:1180px;margin:0 auto;padding:24px}.card{background:#131326;border:1px solid #2d2d4a;border-radius:18px;padding:18px}.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.muted{color:#9ca3af}.btn{background:#7c3aed;color:#fff;border:0;border-radius:12px;padding:10px 13px;cursor:pointer;text-decoration:none;display:inline-block}.btn.gold{background:#f59e0b;color:#160a00}.btn.red{background:#ef4444}.btn.green{background:#10b981}.input{width:100%;padding:10px 12px;border-radius:12px;border:1px solid #384163;background:#0d0d1a;color:#fff;box-sizing:border-box}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #2d2d4a;text-align:left;font-size:13px;vertical-align:top}.pill{display:inline-block;padding:4px 10px;border-radius:999px;background:#243150;color:#dbe4ff}.actions{display:flex;gap:6px;flex-wrap:wrap}.inline{display:inline}.stack{display:grid;gap:8px}h1,h2,h3{margin-top:0}.small{font-size:12px}.danger{color:#fca5a5}.ok{color:#86efac}</style></head><body><div class="wrap">${content}</div></body></html>`;
}

function adminCookieHeader(token: string) {
  return `admin_session=${encodeURIComponent(token)}; HttpOnly; Path=/; SameSite=Lax`;
}

function readSession(req: { headers: { cookie?: string } }) {
  const cookie = String(req.headers.cookie ?? "");
  const match = cookie.match(/(?:^|;\s*)admin_session=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : undefined;
}

function requireAdmin(req: import("express").Request, res: import("express").Response, next: import("express").NextFunction) {
  if (!isAdminSession(readSession(req))) {
    res.status(401).json({ error: "Unauthorized", code: "admin_unauthorized" });
    return;
  }
  next();
}

function requireAdminPanel(req: import("express").Request, res: import("express").Response, next: import("express").NextFunction) {
  if (!isAdminSession(readSession(req))) {
    res.redirect("/admin/login");
    return;
  }
  next();
}

function sendError(res: import("express").Response, err: unknown, fallback: string) {
  const normalized = handleRouteError(err, fallback);
  res.status(normalized.status).json(normalized.body);
}

function htmlEscape(value: unknown) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formRedirect(res: import("express").Response, fallbackJson: unknown) {
  const accepts = String(res.req.headers.accept ?? "");
  if (accepts.includes("text/html")) {
    res.redirect("/admin/dashboard");
  } else {
    res.json(fallbackJson);
  }
}

adminPanelRouter.get("/", (req, res) => {
  if (!isAdminSession(readSession(req))) {
    res.redirect("/admin/login");
    return;
  }
  res.redirect("/admin/dashboard");
});

adminPanelRouter.get("/login", (_req, res) => {
  res.send(adminShell(`<div class="card" style="max-width:420px;margin:80px auto"><h1>Admin Login</h1><p class="muted">Enter ADMIN_PASSWORD to continue.</p><form method="post" action="/admin/login"><input class="input" type="password" name="password" placeholder="ADMIN_PASSWORD" autocomplete="current-password" /><div style="height:12px"></div><button class="btn gold" type="submit">Login</button></form></div>`));
});

adminPanelRouter.post("/login", (req, res) => {
  const password = String(req.body?.password ?? "");
  try {
    if (!validateAdminPassword(password)) {
      res.status(401).send(adminShell(`<div class="card" style="max-width:420px;margin:80px auto"><h1>Admin Login</h1><p class="danger">Invalid password.</p><form method="post" action="/admin/login"><input class="input" type="password" name="password" placeholder="ADMIN_PASSWORD" /><div style="height:12px"></div><button class="btn gold" type="submit">Login</button></form></div>`));
      return;
    }
    const token = createAdminSession();
    res.setHeader("Set-Cookie", adminCookieHeader(token));
    res.redirect("/admin/dashboard");
  } catch (err) {
    const message = err instanceof Error ? err.message : "Admin login failed";
    res.status(500).send(adminShell(`<div class="card"><h1>Admin configuration error</h1><p class="danger">${htmlEscape(message)}</p></div>`));
  }
});

adminPanelRouter.get("/logout", (_req, res) => {
  res.setHeader("Set-Cookie", "admin_session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax");
  res.redirect("/admin/login");
});

adminPanelRouter.get("/dashboard", requireAdminPanel, async (_req, res) => {
  const db = getFirestoreDb();
  const settings = await getAppSettings();
  const [usersSnap, withdrawalsSnap, txSnap, supportSnap] = await Promise.all([
    db.collection("users").orderBy("updatedAt", "desc").limit(30).get(),
    db.collection("withdrawals").orderBy("createdAt", "desc").limit(30).get(),
    db.collection("coinTransactions").orderBy("createdAt", "desc").limit(25).get(),
    db.collection("supportTickets").orderBy("createdAt", "desc").limit(25).get(),
  ]);

  const content = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;gap:12px">
      <div><h1 style="margin:0">Engage-to-Earn Admin</h1><div class="muted">Protected dashboard · /admin</div></div>
      <a class="pill" href="/admin/logout">Logout</a>
    </div>
    <div class="row">
      <div class="card"><div class="muted">Coin Rate</div><h2>1000 = PKR ${settings.coinRatePKR}</h2></div>
      <div class="card"><div class="muted">Spin Limit</div><h2>${settings.spinDailyLimit}/day</h2></div>
      <div class="card"><div class="muted">Scratch Limit</div><h2>${settings.scratchDailyLimit}/day</h2></div>
      <div class="card"><div class="muted">Min Withdrawal</div><h2>PKR ${settings.minimumWithdrawalPKR}</h2></div>
    </div>
    <div style="height:18px"></div>
    <div class="card"><h3>Recent Users</h3><table><thead><tr><th>Device</th><th>Coins</th><th>PKR</th><th>Status</th><th>Admin</th></tr></thead><tbody>${usersSnap.docs.map((doc) => { const data = doc.data(); return `<tr><td>${htmlEscape(data.deviceId)}</td><td>${htmlEscape(data.coinsBalance)}</td><td>${htmlEscape(data.pkrBalance)}</td><td>${data.isBanned ? '<span class="danger">Banned</span>' : '<span class="ok">Active</span>'}</td><td class="actions"><form class="inline" method="post" action="/api/admin/users/${encodeURIComponent(data.deviceId)}/ban"><input type="hidden" name="reason" value="Manual admin ban"/><button class="btn red" type="submit">Ban</button></form><form class="inline" method="post" action="/api/admin/users/${encodeURIComponent(data.deviceId)}/unban"><button class="btn green" type="submit">Unban</button></form><form class="inline" method="post" action="/api/admin/users/${encodeURIComponent(data.deviceId)}/adjust-coins"><input class="input" style="width:95px" name="coinsChange" placeholder="coins"/><input type="hidden" name="reason" value="Manual dashboard adjustment"/><button class="btn" type="submit">Adjust</button></form></td></tr>`; }).join("")}</tbody></table></div>
    <div style="height:18px"></div>
    <div class="card"><h3>Withdrawals</h3><table><thead><tr><th>ID</th><th>Device</th><th>Amount</th><th>Method</th><th>Status</th><th>Admin</th></tr></thead><tbody>${withdrawalsSnap.docs.map((doc) => { const d = doc.data(); return `<tr><td>${htmlEscape(d.withdrawalId)}</td><td>${htmlEscape(d.deviceId)}</td><td>PKR ${htmlEscape(d.amountPKR)}</td><td>${htmlEscape(d.paymentMethod)}<br/><span class="muted small">${htmlEscape(d.accountNumber)} · ${htmlEscape(d.accountTitle)}</span></td><td>${htmlEscape(d.status)}</td><td class="actions"><form class="inline" method="post" action="/api/admin/withdrawals/${encodeURIComponent(d.withdrawalId)}/approve"><button class="btn" type="submit">Approve</button></form><form class="inline" method="post" action="/api/admin/withdrawals/${encodeURIComponent(d.withdrawalId)}/mark-paid"><button class="btn green" type="submit">Paid</button></form><form class="inline" method="post" action="/api/admin/withdrawals/${encodeURIComponent(d.withdrawalId)}/reject"><input class="input" style="width:150px" name="reason" placeholder="reason"/><button class="btn red" type="submit">Reject</button></form></td></tr>`; }).join("")}</tbody></table></div>
    <div style="height:18px"></div>
    <div class="row">
      <div class="card"><h3>Transactions</h3><table><thead><tr><th>Type</th><th>Device</th><th>Coins</th><th>Status</th></tr></thead><tbody>${txSnap.docs.map((doc) => { const d = doc.data(); return `<tr><td>${htmlEscape(d.type)}</td><td>${htmlEscape(d.deviceId)}</td><td>${htmlEscape(d.coinsChange)}</td><td>${htmlEscape(d.status)}</td></tr>`; }).join("")}</tbody></table></div>
      <div class="card"><h3>Support Tickets</h3><table><thead><tr><th>Issue</th><th>Message</th><th>Status</th><th>Admin</th></tr></thead><tbody>${supportSnap.docs.map((doc) => { const d = doc.data(); return `<tr><td>${htmlEscape(d.issueType)}</td><td>${htmlEscape(d.message)}</td><td>${htmlEscape(d.status)}</td><td><form method="post" action="/api/admin/support/${encodeURIComponent(d.ticketId)}/close"><button class="btn" type="submit">Close</button></form></td></tr>`; }).join("")}</tbody></table></div>
    </div>`;
  res.send(adminShell(content));
});

adminApiRouter.use(requireAdmin);

adminApiRouter.get("/stats", async (_req, res) => {
  try {
    const db = getFirestoreDb();
    const settings = await getAppSettings();
    const [usersSnap, withdrawalsSnap, pendingSnap, supportSnap, txSnap] = await Promise.all([
      db.collection("users").get(),
      db.collection("withdrawals").get(),
      db.collection("withdrawals").where("status", "==", "pending").get(),
      db.collection("supportTickets").where("status", "==", "open").get(),
      db.collection("coinTransactions").limit(1).get(),
    ]);
    res.json({ settings, users: usersSnap.size, withdrawals: withdrawalsSnap.size, pendingWithdrawals: pendingSnap.size, openSupportTickets: supportSnap.size, transactionsKnown: txSnap.size > 0 });
  } catch (err) {
    sendError(res, err, "Unable to load admin stats.");
  }
});

adminApiRouter.get("/users", async (_req, res) => {
  try {
    const snap = await getFirestoreDb().collection("users").orderBy("updatedAt", "desc").limit(200).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    sendError(res, err, "Unable to load users.");
  }
});

adminApiRouter.get("/users/:deviceId", async (req, res) => {
  try {
    const snap = await getFirestoreDb().collection("users").doc(req.params.deviceId).get();
    if (!snap.exists) {
      res.status(404).json({ error: "User not found.", code: "user_not_found" });
      return;
    }
    res.json(serializeDoc({ id: snap.id, ...snap.data() }));
  } catch (err) {
    sendError(res, err, "Unable to load user.");
  }
});

adminApiRouter.post("/users/:deviceId/ban", async (req, res) => {
  try {
    await getFirestoreDb().collection("users").doc(req.params.deviceId).set({ isBanned: true, banReason: String(req.body?.reason ?? "Manual admin ban"), bannedAt: nowTs(), updatedAt: nowTs() }, { merge: true });
    formRedirect(res, { success: true, message: "User banned." });
  } catch (err) {
    sendError(res, err, "Unable to ban user.");
  }
});

adminApiRouter.post("/users/:deviceId/unban", async (req, res) => {
  try {
    await getFirestoreDb().collection("users").doc(req.params.deviceId).set({ isBanned: false, banReason: null, bannedAt: null, updatedAt: nowTs() }, { merge: true });
    formRedirect(res, { success: true, message: "User unbanned." });
  } catch (err) {
    sendError(res, err, "Unable to unban user.");
  }
});

adminApiRouter.post("/users/:deviceId/adjust-coins", async (req, res) => {
  try {
    const coinsChange = Number(req.body?.coinsChange);
    if (!Number.isFinite(coinsChange) || coinsChange === 0) {
      res.status(400).json({ error: "coinsChange must be a non-zero number.", code: "invalid_adjustment" });
      return;
    }
    const result = await adjustUserCoins(req.params.deviceId, Math.trunc(coinsChange), String(req.body?.reason ?? "Manual admin adjustment"));
    formRedirect(res, result);
  } catch (err) {
    sendError(res, err, "Unable to adjust coins.");
  }
});

adminApiRouter.get("/withdrawals", async (_req, res) => {
  try {
    const snap = await getFirestoreDb().collection("withdrawals").orderBy("createdAt", "desc").limit(200).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    sendError(res, err, "Unable to load withdrawals.");
  }
});

adminApiRouter.post("/withdrawals/:withdrawalId/approve", async (req, res) => {
  try {
    const result = await markWithdrawalStatus(req.params.withdrawalId, "approved", String(req.body?.adminNote ?? ""));
    formRedirect(res, result);
  } catch (err) {
    sendError(res, err, "Unable to approve withdrawal.");
  }
});

adminApiRouter.post("/withdrawals/:withdrawalId/reject", async (req, res) => {
  try {
    const result = await rejectWithdrawal(req.params.withdrawalId, String(req.body?.reason ?? "Rejected by admin"));
    formRedirect(res, result);
  } catch (err) {
    sendError(res, err, "Unable to reject withdrawal.");
  }
});

adminApiRouter.post("/withdrawals/:withdrawalId/mark-paid", async (req, res) => {
  try {
    const result = await markWithdrawalStatus(req.params.withdrawalId, "paid", String(req.body?.adminNote ?? ""));
    formRedirect(res, result);
  } catch (err) {
    sendError(res, err, "Unable to mark withdrawal paid.");
  }
});

adminApiRouter.get("/transactions", async (_req, res) => {
  try {
    const snap = await getFirestoreDb().collection("coinTransactions").orderBy("createdAt", "desc").limit(300).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    sendError(res, err, "Unable to load transactions.");
  }
});

adminApiRouter.get("/support", async (_req, res) => {
  try {
    const snap = await getFirestoreDb().collection("supportTickets").orderBy("createdAt", "desc").limit(200).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    sendError(res, err, "Unable to load support tickets.");
  }
});

adminApiRouter.post("/support/:ticketId/close", async (req, res) => {
  try {
    await getFirestoreDb().collection("supportTickets").doc(req.params.ticketId).set({ status: "closed", updatedAt: nowTs() }, { merge: true });
    formRedirect(res, { success: true, message: "Ticket closed." });
  } catch (err) {
    sendError(res, err, "Unable to close ticket.");
  }
});

export default adminPanelRouter;
