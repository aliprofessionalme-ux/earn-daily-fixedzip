import { Router } from "express";
import { z } from "zod";
import { getFirestoreDb, handleRouteError, serializeDoc, submitWithdrawal } from "../services/firebase-admin.js";

const router = Router({ mergeParams: true });

const withdrawalSchema = z.object({
  paymentMethod: z.enum(["Easypaisa", "JazzCash"]),
  accountNumber: z.string().min(5),
  accountTitle: z.string().min(2),
  amountPKR: z.number().int().positive(),
});

function sendError(res: import("express").Response, err: unknown, fallback: string) {
  const normalized = handleRouteError(err, fallback);
  res.status(normalized.status).json(normalized.body);
}

router.get("/", async (req, res) => {
  try {
    const db = getFirestoreDb();
    const snap = await db.collection("withdrawals").where("deviceId", "==", req.params.deviceId).orderBy("createdAt", "desc").limit(100).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    req.log.error({ err }, "Error fetching withdrawals");
    sendError(res, err, "Unable to load withdrawals.");
  }
});

router.post("/", async (req, res) => {
  const parsed = withdrawalSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter valid payment method, account details and PKR amount.", code: "invalid_withdrawal_request" });
    return;
  }

  try {
    res.json(await submitWithdrawal(req.params.deviceId, parsed.data));
  } catch (err) {
    req.log.error({ err }, "Error submitting withdrawal");
    sendError(res, err, "Unable to submit withdrawal.");
  }
});

export default router;
