import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import usersRouter from "./users.js";
import withdrawalsRouter from "./withdrawals.js";
import webhooksRouter from "./webhooks.js";
import { adminApiRouter } from "./admin.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/admin", adminApiRouter);
router.use("/users", usersRouter);
router.use("/users/:deviceId/withdrawals", withdrawalsRouter);
router.use("/webhooks", webhooksRouter);

export default router;
