import { Router } from "express";
import { z } from "zod";
import {
  creditCheckIn,
  creditScratch,
  creditSpin,
  getFirestoreDb,
  getUserDoc,
  handleRouteError,
  initUser,
  serializeDoc,
  serializeUser,
} from "../services/firebase-admin.js";

const router = Router();

const initSchema = z.object({
  deviceId: z.string().min(6),
  installId: z.string().min(6).optional().nullable(),
  deviceFingerprint: z.string().min(6).optional().nullable(),
  firebaseUid: z.string().optional().nullable(),
  firebaseToken: z.string().optional().nullable(),
  authMode: z.enum(["firebase-anonymous", "device-only"]).optional(),
  authVerified: z.boolean().optional(),
  deviceInfo: z.record(z.unknown()).optional().nullable(),
});

const supportSchema = z.object({
  issueType: z.string().min(2).max(60),
  message: z.string().min(5).max(2000),
});

function sendError(res: import("express").Response, err: unknown, fallback: string) {
  const normalized = handleRouteError(err, fallback);
  res.status(normalized.status).json(normalized.body);
}

router.post("/init", async (req, res) => {
  const parsed = initSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "deviceId and valid device metadata are required.", code: "invalid_init_request" });
    return;
  }

  try {
    const result = await initUser(parsed.data);
    res.json({ ...serializeUser(result.user), duplicateRestored: result.duplicateRestored, authWarning: result.authWarning ?? null });
  } catch (err) {
    req.log.error({ err }, "Error initializing user");
    sendError(res, err, "Unable to initialize user.");
  }
});

router.get("/:deviceId/transactions", async (req, res) => {
  try {
    const db = getFirestoreDb();
    const snap = await db.collection("coinTransactions").where("deviceId", "==", req.params.deviceId).orderBy("createdAt", "desc").limit(100).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    req.log.error({ err }, "Error fetching transactions");
    sendError(res, err, "Unable to load transaction history.");
  }
});

router.get("/:deviceId/support", async (req, res) => {
  try {
    const db = getFirestoreDb();
    const snap = await db.collection("supportTickets").where("deviceId", "==", req.params.deviceId).orderBy("createdAt", "desc").limit(50).get();
    res.json(snap.docs.map((doc) => serializeDoc({ id: doc.id, ...doc.data() })));
  } catch (err) {
    req.log.error({ err }, "Error fetching support tickets");
    sendError(res, err, "Unable to load support tickets.");
  }
});

router.post("/:deviceId/support", async (req, res) => {
  const parsed = supportSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose an issue type and enter a message of at least 5 characters.", code: "invalid_support_request" });
    return;
  }

  try {
    const user = await getUserDoc(req.params.deviceId);
    if (!user) {
      res.status(404).json({ error: "User not found.", code: "user_not_found" });
      return;
    }
    const db = getFirestoreDb();
    const ticketRef = db.collection("supportTickets").doc();
    const ticket = {
      ticketId: ticketRef.id,
      deviceId: req.params.deviceId,
      issueType: parsed.data.issueType.trim(),
      message: parsed.data.message.trim(),
      status: "open",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await ticketRef.set(ticket);
    res.json({ success: true, message: "Support ticket submitted.", ...ticket, createdAt: ticket.createdAt.toISOString(), updatedAt: ticket.updatedAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Error creating support ticket");
    sendError(res, err, "Unable to create support ticket.");
  }
});

router.get("/:deviceId", async (req, res) => {
  try {
    const user = await getUserDoc(req.params.deviceId);
    if (!user) {
      res.status(404).json({ error: "User not found.", code: "user_not_found" });
      return;
    }
    res.json(serializeUser(user));
  } catch (err) {
    req.log.error({ err }, "Error fetching user");
    sendError(res, err, "Unable to fetch user.");
  }
});

router.post("/:deviceId/checkin", async (req, res) => {
  try {
    res.json(await creditCheckIn(req.params.deviceId));
  } catch (err) {
    req.log.error({ err }, "Error during check-in");
    sendError(res, err, "Reward failed. Please try again.");
  }
});

router.post("/:deviceId/spin", async (req, res) => {
  try {
    res.json(await creditSpin(req.params.deviceId));
  } catch (err) {
    req.log.error({ err }, "Error recording spin");
    sendError(res, err, "Spin reward failed. Please try again.");
  }
});

router.post("/:deviceId/scratch", async (req, res) => {
  try {
    res.json(await creditScratch(req.params.deviceId));
  } catch (err) {
    req.log.error({ err }, "Error recording scratch");
    sendError(res, err, "Scratch reward failed. Please try again.");
  }
});

export default router;
