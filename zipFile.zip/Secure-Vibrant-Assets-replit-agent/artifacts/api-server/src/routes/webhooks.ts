import { Router } from "express";
import { creditOfferwallReward, handleRouteError } from "../services/firebase-admin.js";

const router = Router();

function sendError(res: import("express").Response, err: unknown, fallback: string) {
  const normalized = handleRouteError(err, fallback);
  res.status(normalized.status).json(normalized.body);
}

router.post("/monlix", async (req, res) => {
  const { userId, rewardAmount, secret, transactionId } = req.body as {
    userId?: string;
    rewardAmount?: number;
    secret?: string;
    transactionId?: string;
  };

  const expectedSecret = process.env["MONLIX_API_SECRET"];
  if (!expectedSecret) {
    res.status(500).json({ error: "Monlix webhook secret is not configured.", code: "webhook_secret_missing" });
    return;
  }
  if (!secret || secret !== expectedSecret) {
    res.status(403).json({ error: "Invalid webhook secret.", code: "invalid_webhook_secret" });
    return;
  }
  if (!userId || typeof rewardAmount !== "number" || rewardAmount <= 0) {
    res.status(400).json({ error: "Invalid Monlix webhook payload.", code: "invalid_webhook_payload" });
    return;
  }

  try {
    const result = await creditOfferwallReward({
      deviceId: userId,
      rewardAmount,
      externalTransactionId: transactionId ?? `${userId}_${Date.now()}`,
      source: "monlix",
      payload: req.body as Record<string, unknown>,
    });
    res.json(result);
  } catch (err) {
    req.log.error({ err, userId }, "Error processing Monlix webhook");
    sendError(res, err, "Unable to process Monlix reward.");
  }
});

export default router;
