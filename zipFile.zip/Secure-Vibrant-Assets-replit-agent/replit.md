# Engage to Earn

A vibrant "Engage-to-Earn" Android mobile app where users earn coins through daily check-ins, spin wheel, scratch cards, and Monlix offerwalls, then withdraw their earnings via Easypaisa or JazzCash.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/mobile run dev` — run the Expo app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Mobile: React Native + Expo (managed workflow), Expo Router
- API: Express 5
- Database: Firebase Firestore (client SDK on mobile, Admin SDK on server)
- Device tracking: expo-secure-store + expo-application (Android ID)
- Validation: Zod (`zod/v4`)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/mobile/` — Expo React Native app
  - `app/(tabs)/index.tsx` — Dashboard screen
  - `app/(tabs)/games.tsx` — Spin Wheel + Scratch Card games
  - `app/(tabs)/offerwall.tsx` — Monlix WebView offerwall
  - `app/(tabs)/wallet.tsx` — Wallet & withdrawal form
  - `contexts/UserContext.tsx` — Device ID + user data state
  - `services/firebase.ts` — Firebase client SDK (Firestore)
  - `constants/colors.ts` — Dark vibrant theme tokens
- `artifacts/api-server/` — Express backend
  - `src/routes/users.ts` — User init, check-in, spin, scratch
  - `src/routes/withdrawals.ts` — Withdrawal CRUD
  - `src/routes/webhooks.ts` — Monlix reward webhook
  - `src/services/firebase-admin.ts` — Firebase Admin SDK
- `lib/api-spec/openapi.yaml` — API contract (source of truth)

## Architecture decisions

- Device ID is generated using Android ID (expo-application) or a random UUID stored in expo-secure-store — no Firebase Auth required
- Mobile app reads/writes Firestore directly for user data; coin-awarding operations go through the Express backend to prevent client-side cheating
- Monlix webhook validates a shared secret before crediting coins
- 1000 coins = PKR 20 conversion enforced both on client and server
- Minimum withdrawal: PKR 500

## Product

- Dashboard: coins balance, PKR balance, daily check-in (+50 coins), navigation to all features
- Games: Spin wheel (max 10/day, 5-100 coins) + scratch card (max 10/day, 10-50 coins)
- Offerwall: Monlix WebView embedded with the user's deviceId as tracking parameter
- Wallet: withdrawal form (Easypaisa/JazzCash), transaction history with status badges

## Required Secrets

### Mobile app (EXPO_PUBLIC_ prefix required for Metro bundler)
- `EXPO_PUBLIC_FIREBASE_API_KEY`
- `EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `EXPO_PUBLIC_FIREBASE_PROJECT_ID`
- `EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `EXPO_PUBLIC_FIREBASE_APP_ID`
- `EXPO_PUBLIC_MONLIX_APP_ID` — your Monlix App ID

### Backend server
- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL` — Firebase service account email
- `FIREBASE_PRIVATE_KEY` — Firebase service account private key
- `MONLIX_API_SECRET` — shared secret to validate Monlix webhooks

## Gotchas

- Firebase client SDK needs `EXPO_PUBLIC_` prefixed secrets for Expo bundler
- Firebase Admin SDK needs a service account (client email + private key), not just the web SDK credentials
- Monlix webhook URL on the backend: `POST /api/webhooks/monlix`
- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec change
